const fares = {
  "বাসাবো-যমুনা ফিউচার পার্ক": "২৫–৩০ টাকা",
  "মতিঝিল-উত্তরা": "৩০–৪০ টাকা",
  "গুলিস্তান-মিরপুর": "২৫–৩৫ টাকা",
  "ধানমন্ডি-মতিঝিল": "২০–২৫ টাকা",
  "শ্যামলী-বনানী": "২০–৩০ টাকা"
};

function checkFare() {
  const from = document.getElementById('from').value.trim();
  const to = document.getElementById('to').value.trim();
  const key = `${from}-${to}`;
  const reverseKey = `${to}-${from}`;
  const resultDiv = document.getElementById('result');

  if (fares[key]) {
    resultDiv.innerHTML = `💰 আনুমানিক ভাড়া: <b>${fares[key]}</b>`;
  } else if (fares[reverseKey]) {
    resultDiv.innerHTML = `💰 আনুমানিক ভাড়া: <b>${fares[reverseKey]}</b>`;
  } else {
    resultDiv.innerHTML = "⚠️ দুঃখিত, এই রুটের তথ্য এখনো যুক্ত হয়নি।";
  }
}
